from __future__ import annotations

import logging
import time
from threading import Event, Lock, Thread
from typing import Any, Optional

import cv2
import numpy as np
import pyorbbecsdk as ob

from lerobot.utils.errors import DeviceAlreadyConnectedError, DeviceNotConnectedError
from ..camera import Camera
from ..configs import CameraConfig, ColorMode
from ..utils import get_cv2_rotation
from .configuration_orbbec import (
    OrbbecCameraConfig,
    OrbbecColorCameraConfig,
    OrbbecDepthCameraConfig,
)

logger = logging.getLogger(__name__)

class OrbbecPipeline:
    """
    全局唯一 Orbbec pipeline 管理者（Singleton）。

    职责（清晰分界）：
      - 聚合多个 Camera 的能力声明（color / depth）
      - 协商 pipeline 级参数（fps / width / height）的一致性
      - 负责启动 Orbbec SDK 的 pipeline（.start）并运行一个 *唯一的* 后台采集线程，
        该线程是唯一调用 wait_for_frames() 的位置。
      - 提供线程安全的 get_latest_frames() 供 Camera 视图读取（非阻塞）。

    设计原则：
      - 参数协商与启动为原子操作（由类级锁保护）
      - 只允许一个 producer（pipeline._read_loop）写 latest_frames
      - Camera 只读 latest_frames（通过 frame_lock）
    """

    _instance = None
    _lock = Lock()  # 用于 singleton 创建 + 参数协商保护

    def __init__(self):
        # Orbbec SDK 对象（延后创建）
        self.pipeline = None
        self.config = None
        self.started = False
        self._started_enable_color = False
        self._started_enable_depth = False

        # 能力声明（外部 register_camera 设置）
        self.enable_color = False
        self.enable_depth = False

        # 协商后确定的 pipeline 参数
        # 约束：同一个 pipeline 下，fps 必须一致；但 color/depth 分辨率允许不同
        self.fps: Optional[int] = None
        self.color_width: Optional[int] = None
        self.color_height: Optional[int] = None
        self.depth_width: Optional[int] = None
        self.depth_height: Optional[int] = None

        # 帧缓存（保护 latest_frames 的锁）
        self.frame_lock = Lock()
        self.latest_frames = None  # SDK frames object (完整的一帧组)
        self.frames_seq: int = 0
        self.last_frames_ts: float | None = None
        self.consecutive_wait_failures: int = 0
        self.total_wait_failures: int = 0
        self.total_wait_exceptions: int = 0
        self.last_wait_exception: str | None = None
        self._last_status_log_ts: float = 0.0

        # 采集线程控制
        self.thread: Optional[Thread] = None
        self.stop_event: Event = Event()

    @classmethod
    def get(cls) -> "OrbbecPipeline":
        with cls._lock:
            if cls._instance is None:
                cls._instance = cls()
            return cls._instance

    def register_camera(self, cfg: "CameraConfig", kind: str):
        """
        注册一个 Camera 的需求到 pipeline（线程安全）。

        - cfg: Camera 的配置对象（包含 fps/width/height/warmup_s 等）
        - kind: "color" 或 "depth"
        """
        with self._lock:
            # 能力声明
            if kind == "color":
                self.enable_color = True
            elif kind == "depth":
                self.enable_depth = True
            else:
                raise ValueError(f"Unknown camera kind: {kind}")

            # 协商 fps/width/height：第一次写入后固定，任何不一致都会抛错
            # 协商 fps：第一次写入后固定，不一致则抛错（同一 pipeline 下必须一致）
            v_fps = getattr(cfg, "fps", None)
            if v_fps is not None:
                if self.fps is None:
                    self.fps = v_fps
                elif self.fps != v_fps:
                    raise ValueError(
                        f"Pipeline parameter conflict on `fps`: "
                        f"{self.fps} (existing) vs {v_fps} (from {kind})"
                    )

            # 分辨率允许 color/depth 不同，但同一种流（color 或 depth）内部必须一致
            v_w = getattr(cfg, "width", None)
            v_h = getattr(cfg, "height", None)
            if kind == "color":
                if v_w is not None:
                    if self.color_width is None:
                        self.color_width = v_w
                    elif self.color_width != v_w:
                        raise ValueError(
                            f"Pipeline parameter conflict on `color_width`: "
                            f"{self.color_width} (existing) vs {v_w} (from {kind})"
                        )
                if v_h is not None:
                    if self.color_height is None:
                        self.color_height = v_h
                    elif self.color_height != v_h:
                        raise ValueError(
                            f"Pipeline parameter conflict on `color_height`: "
                            f"{self.color_height} (existing) vs {v_h} (from {kind})"
                        )
            elif kind == "depth":
                if v_w is not None:
                    if self.depth_width is None:
                        self.depth_width = v_w
                    elif self.depth_width != v_w:
                        raise ValueError(
                            f"Pipeline parameter conflict on `depth_width`: "
                            f"{self.depth_width} (existing) vs {v_w} (from {kind})"
                        )
                if v_h is not None:
                    if self.depth_height is None:
                        self.depth_height = v_h
                    elif self.depth_height != v_h:
                        raise ValueError(
                            f"Pipeline parameter conflict on `depth_height`: "
                            f"{self.depth_height} (existing) vs {v_h} (from {kind})"
                        )

    def start(self):
        """
        启动 Orbbec pipeline 以及后台采集线程（只允许一次，线程安全）。

        重要校验：
          - 如果启用了 color 或 depth 且 width/fps/height 为 None -> 报错
            （避免 SDK 在缺少必需参数时崩溃或使用未定义行为）
        """
        with self._lock:
            # 如果 pipeline 已启动，但后续又注册了新的 stream 需求（例如先 connect color 再 connect depth），
            # 则必须重启 pipeline 才能让新 stream 生效。否则对应 read() 会一直返回 None，async_read 会持续超时。
            if self.started:
                if (
                    self._started_enable_color == self.enable_color
                    and self._started_enable_depth == self.enable_depth
                ):
                    return
                logger.info(
                    "Restarting Orbbec pipeline to apply stream requirements: "
                    f"color {self._started_enable_color}->{self.enable_color}, "
                    f"depth {self._started_enable_depth}->{self.enable_depth}"
                )
                self._restart_locked()

            # 在启用任一路流的情况下，fps 必须指定；分辨率需针对开启的流分别指定
            if (self.enable_color or self.enable_depth) and self.fps is None:
                raise RuntimeError("Pipeline start requires `fps` to be set by camera configs.")
            if self.enable_color and (self.color_width is None or self.color_height is None):
                raise RuntimeError(
                    "Pipeline start requires `width`/`height` for color stream to be set by camera configs."
                )
            if self.enable_depth and (self.depth_width is None or self.depth_height is None):
                raise RuntimeError(
                    "Pipeline start requires `width`/`height` for depth stream to be set by camera configs."
                )

            logger.info(
                "Starting Orbbec pipeline with "
                f"enable_color={self.enable_color}, enable_depth={self.enable_depth}, "
                f"color={self.color_width}x{self.color_height}, "
                f"depth={self.depth_width}x{self.depth_height}, fps={self.fps}"
            )

            # 创建 SDK 对象并启用对应流
            self.pipeline = ob.Pipeline()
            self.config = ob.Config()

            if self.enable_depth:
                profiles = self.pipeline.get_stream_profile_list(ob.OBSensorType.DEPTH_SENSOR)
                depth_profile = profiles.get_video_stream_profile(
                    self.depth_width, self.depth_height, ob.OBFormat.Y16, self.fps
                )
                logger.info(
                    "Enabled DEPTH stream "
                    f"{self.depth_width}x{self.depth_height}@{self.fps} format=Y16"
                )
                self.config.enable_stream(depth_profile)

            if self.enable_color:
                profiles = self.pipeline.get_stream_profile_list(ob.OBSensorType.COLOR_SENSOR)
                color_profile = profiles.get_video_stream_profile(
                    self.color_width, self.color_height, ob.OBFormat.RGB, self.fps
                )
                logger.info(
                    "Enabled COLOR stream "
                    f"{self.color_width}x{self.color_height}@{self.fps} format=RGB"
                )
                self.config.enable_stream(color_profile)

            # 启动 SDK pipeline（阻塞/异常可能来自 SDK，自行处理）
            self.pipeline.start(self.config)
            self.started = True
            self._started_enable_color = self.enable_color
            self._started_enable_depth = self.enable_depth
            self.frames_seq = 0
            self.last_frames_ts = None
            self.consecutive_wait_failures = 0
            self.total_wait_failures = 0
            self.total_wait_exceptions = 0
            self.last_wait_exception = None

            # 启动唯一的后台采集线程（daemon）
            self.stop_event = Event()
            self.thread = Thread(target=self._read_loop, name="OrbbecPipeline_read_loop", daemon=True)
            self.thread.start()

    def _restart_locked(self) -> None:
        """
        需在持有 self._lock 的情况下调用。
        停止现有采集线程与 SDK pipeline，然后清空状态，以便后续重新 start()。
        """
        try:
            if self.thread is not None and self.thread.is_alive():
                self.stop_event.set()
                self.thread.join(timeout=2.0)
        finally:
            self.thread = None
            self.stop_event = Event()

        if self.pipeline is not None:
            try:
                self.pipeline.stop()
            except Exception as e:
                logger.warning(f"Error stopping pipeline during restart: {e}")

        self.pipeline = None
        self.config = None
        self.started = False
        self._started_enable_color = False
        self._started_enable_depth = False

        with self.frame_lock:
            self.latest_frames = None
            self.frames_seq = 0
            self.last_frames_ts = None

        self.consecutive_wait_failures = 0
        self.total_wait_failures = 0
        self.total_wait_exceptions = 0
        self.last_wait_exception = None

    def _read_loop(self):
        """
        唯一允许调用 wait_for_frames() 的地方（producer）。
        将 SDK frames 原子地写入 latest_frames（通过 frame_lock 保护）。
        保证了 color/depth 来自同一 frames 对象。
        """
        while not self.stop_event.is_set():
            try:
                # wait_for_frames 超时不宜过长，否则 stop/restart 不灵敏（这里设为 1000ms）
                frames = self.pipeline.wait_for_frames(1000)
                if frames is None:
                    self.consecutive_wait_failures += 1
                    self.total_wait_failures += 1
                    now = time.time()
                    if now - self._last_status_log_ts > 2.0:
                        self._last_status_log_ts = now
                        logger.warning(
                            "Orbbec pipeline wait_for_frames() returned None "
                            f"(consecutive={self.consecutive_wait_failures}, total={self.total_wait_failures})."
                        )
                    continue

                self.consecutive_wait_failures = 0
                now = time.time()
                with self.frame_lock:
                    # 整体替换 latest_frames，读者通过 frame_lock 读取
                    self.latest_frames = frames
                    self.frames_seq += 1
                    self.last_frames_ts = now
            except Exception as e:
                # 记录并继续。不要把线程抛出，否则会终止采集。
                self.total_wait_exceptions += 1
                self.last_wait_exception = repr(e)
                now = time.time()
                if now - self._last_status_log_ts > 2.0:
                    self._last_status_log_ts = now
                    logger.warning(
                        "Pipeline read loop exception "
                        f"(exceptions={self.total_wait_exceptions}, consecutive_none={self.consecutive_wait_failures}): {e}"
                    )
                continue

    def get_latest_frames(self):
        """
        提供给 Camera 的只读接口（线程安全）。
        返回 SDK frames 对象（可能为 None）。
        """
        with self.frame_lock:
            return self.latest_frames

    def get_latest_frames_and_seq(self):
        """
        返回 (latest_frames, frames_seq) 的一致快照（线程安全）。
        用于 Camera 侧避免对同一帧组重复做后处理，从而避免 CPU 空转导致帧率下降。
        """
        with self.frame_lock:
            return self.latest_frames, self.frames_seq

    def get_status(self) -> dict[str, Any]:
        with self.frame_lock:
            last_ts = self.last_frames_ts
            seq = self.frames_seq
        age_s = None if last_ts is None else (time.time() - last_ts)
        return {
            "started": self.started,
            "enable_color": self.enable_color,
            "enable_depth": self.enable_depth,
            "fps": self.fps,
            "color_width": self.color_width,
            "color_height": self.color_height,
            "depth_width": self.depth_width,
            "depth_height": self.depth_height,
            "frames_seq": seq,
            "last_frames_age_s": age_s,
            "consecutive_wait_failures": self.consecutive_wait_failures,
            "total_wait_failures": self.total_wait_failures,
            "total_wait_exceptions": self.total_wait_exceptions,
            "last_wait_exception": self.last_wait_exception,
            "thread_alive": (self.thread is not None and self.thread.is_alive()),
        }

    def stop(self, stop_pipeline: bool = True):
        """
        停止采集线程并（可选）停止底层 SDK pipeline。
        """
        with self._lock:
            if self.thread is not None and self.thread.is_alive():
                self.stop_event.set()
                self.thread.join(timeout=2.0)
            self.thread = None
            self.stop_event = Event()
            self.started = False
            self._started_enable_color = False
            self._started_enable_depth = False
            with self.frame_lock:
                self.latest_frames = None
                self.frames_seq = 0
                self.last_frames_ts = None

            if stop_pipeline and self.pipeline is not None:
                try:
                    self.pipeline.stop()
                except Exception:
                    # SDK stop 可能不存在或抛异常，忽略但记录
                    logger.warning("Error stopping pipeline.")
                self.pipeline = None
                self.config = None


# -------------------------
# Camera 层（Base + Color + Depth）
# -------------------------

class OrbbecBaseCamera(Camera):
    """
    Orbbec 逻辑相机基类。

    职责：
      - 将自身 config 注册到 OrbbecPipeline
      - 管理视图级的后台线程（_read_loop / async_read）
      - 子类只需实现 read()（从 pipeline.get_latest_frames() 里提取视图并后处理）
    """

    KIND = None  # 子类必须覆盖为 "color" 或 "depth"

    def __init__(self, config: "CameraConfig"):
        super().__init__(config)
        self.config = config
        self.pipeline = OrbbecPipeline.get()
        self.connected = False

        # async_read 相关成员（用于每个逻辑相机独立的视图缓存）
        self.thread: Optional[Thread] = None
        self.stop_event: Optional[Event] = None
        self.frame_lock = Lock()       # 保护 latest_frame
        self.latest_frame = None       # 子类 read() 产生的视图（numpy array）
        self.new_frame_event = Event() # 写入 latest_frame 后设置，读端等待并清除
        self._last_frame_ts: float | None = None
        self._none_frame_count: int = 0
        self._ok_frame_count: int = 0
        self._last_none_log_ts: float = 0.0
        self._last_pipeline_seq: int = -1

        # 方便的常用值
        self.rotation = get_cv2_rotation(config.rotation)

    @property
    def is_connected(self) -> bool:
        return self.connected

    @staticmethod
    def find_cameras() -> list[dict[str, Any]]:
        found_cameras_info = []
        context = ob.Context()
        device_list = context.query_devices()

        for device in device_list:
            camera_info = {}

            sensors = device.query_sensors()
            for sensor in sensors:
                profiles = sensor.get_stream_profiles()

                for profile in profiles:
                    if profile.is_video_stream_profile() and profile.is_default():
                        vprofile = profile.as_video_stream_profile()
                        stream_info = {
                            "stream_type": vprofile.stream_name(),
                            "format": vprofile.format().name,
                            "width": vprofile.width(),
                            "height": vprofile.height(),
                            "fps": vprofile.fps(),
                        }
                        camera_info["default_stream_profile"] = stream_info

            found_cameras_info.append(camera_info)

        return found_cameras_info

    def connect(self, warmup: bool = True):
        """
        注册需求并启动 pipeline（pipeline.start 由 pipeline 管理保证只会执行一次）。
        这里也做 warmup：等待当前逻辑相机能读到第一帧（直到 warmup 超时）。
        """
        if self.connected:
            return

        if self.KIND is None:
            raise RuntimeError("KIND must be set by subclass to 'color' or 'depth'")

        # 声明能力并协商参数（线程安全）
        self.pipeline.register_camera(self.config, self.KIND)

        # 启动 pipeline（只有第一次会真正启动 SDK）
        self.pipeline.start()

        # warmup：等待当前 camera 视图能读到帧（由 config.warmup_s 决定）
        # 仅等待 frames object != None 仍可能拿不到 color/depth view，因此这里直接用 self.read() 校验。
        if warmup:
            warmup_s = getattr(self.config, "warmup_s", 0) or 5
            start_t = time.time()
            got_frame = False
            last_error: Exception | None = None
            while time.time() - start_t < warmup_s:
                try:
                    if self.read() is not None:
                        got_frame = True
                        break
                except Exception as e:
                    last_error = e
                time.sleep(0.05)  # 避免 warmup busy loop 占满 CPU

            if not got_frame and warmup_s:
                msg = (
                    f"Warmup timed out after {warmup_s}s for {self} "
                    f"(kind={self.KIND}). First frame may arrive later."
                )
                if last_error is not None:
                    logger.warning(f"{msg} Last error during warmup: {last_error}")
                else:
                    logger.warning(msg)
                logger.warning(f"Pipeline status at warmup timeout: {self.pipeline.get_status()}")
            elif got_frame:
                logger.info(
                    f"Warmup succeeded for {self} (kind={self.KIND}) in {time.time() - start_t:.3f}s."
                )

        self.connected = True

    # ------------------------
    # 视图级后台线程 / async_read
    # ------------------------
    def _read_loop(self):
        """
        逻辑相机的后台线程：周期性调用子类的 read()（该 read() 仅从 pipeline.get_latest_frames() 读取并后处理），
        将结果写入 self.latest_frame 并通过 self.new_frame_event 通知等待者。
        """
        # 注意：这里使用 self.read()，而不是直接调用 SDK。
        while not (self.stop_event and self.stop_event.is_set()):
            try:
                # 仅在 pipeline 产出新 frames 组时才做一次后处理，避免对同一帧重复计算（会显著拖慢系统）
                frames, seq = self.pipeline.get_latest_frames_and_seq()
                if frames is None or seq == self._last_pipeline_seq:
                    time.sleep(0.001)
                    continue
                self._last_pipeline_seq = seq

                frame = self.read()  # 子类实现，从 pipeline.get_latest_frames() 获取视图
                if frame is None:
                    # 没有可用帧则继续等待（pipeline 可能尚未产出第一帧）
                    self._none_frame_count += 1
                    now = time.time()
                    if now - self._last_none_log_ts > 2.0:
                        self._last_none_log_ts = now
                        logger.debug(
                            f"{self} (kind={self.KIND}) read() returned None "
                            f"(none_count={self._none_frame_count}, ok_count={self._ok_frame_count}). "
                            f"Pipeline status: {self.pipeline.get_status()}"
                        )
                    time.sleep(0.001)
                    continue
                with self.frame_lock:
                    self.latest_frame = frame
                    # set() 之前完成写入，保证读者不会见到中间态
                    self.new_frame_event.set()
                self._ok_frame_count += 1
                self._last_frame_ts = time.time()
            except DeviceNotConnectedError:
                # 如果上层断开设备，退出线程
                break
            except Exception as e:
                logger.warning(f"Error reading frame in camera _read_loop for {self}: {e}")
                # 容错：不要终止线程，记录日志并继续
                time.sleep(0.05)

    def _start_read_thread(self) -> None:
        """
        启动逻辑相机的后台线程（若已存在则不重复启动）。
        线程守护模式，便于进程退出时自动结束（仍建议显式 stop）。
        """
        if self.thread is not None and self.thread.is_alive():
            return

        self.stop_event = Event()
        self.thread = Thread(target=self._read_loop, name=f"{self.__class__.__name__}_read_loop", daemon=True)
        self.thread.start()

    def _stop_read_thread(self):
        """
        停止并清理逻辑相机的后台线程。
        """
        if self.stop_event is not None:
            self.stop_event.set()
        if self.thread is not None and self.thread.is_alive():
            self.thread.join(timeout=2.0)
        self.thread = None
        self.stop_event = None

    def async_read(self, timeout_ms: float = 5000) -> np.ndarray:
        """
        非阻塞接口：确保后台线程运行并等待下一个可用视图（最多等待 timeout_ms 毫秒）。
        返回：numpy.ndarray（frame）
        可能抛出：
          - DeviceNotConnectedError
          - TimeoutError
          - RuntimeError（如果 event 被触发但 frame 丢失）
        """
        if not self.connected:
            raise DeviceNotConnectedError(f"{self} is not connected.")

        # 启动线程（如果尚未运行）
        if self.thread is None or not self.thread.is_alive():
            self._start_read_thread()

        # 等待事件，单位秒
        if not self.new_frame_event.wait(timeout=timeout_ms / 1000.0):
            last_age = None if self._last_frame_ts is None else (time.time() - self._last_frame_ts)
            logger.warning(
                f"Timed out waiting for frame from {self} (kind={self.KIND}) after {timeout_ms}ms. "
                f"thread_alive={(self.thread is not None and self.thread.is_alive())}, "
                f"last_frame_age_s={last_age}, "
                f"none_count={self._none_frame_count}, ok_count={self._ok_frame_count}, "
                f"pipeline_status={self.pipeline.get_status()}"
            )
            raise TimeoutError(f"Timed out waiting for frame from camera {self}.")

        # 读取并清除事件
        with self.frame_lock:
            frame = self.latest_frame
            # 清除事件代表"已消费该帧"
            self.new_frame_event.clear()

        if frame is None:
            raise RuntimeError(f"Event set but no frame available for {self}.")

        return frame

    def disconnect(self) -> None:
        if not self.connected and self.thread is None:
            raise DeviceNotConnectedError(f"{self} already disconnected.")

        if self.thread is not None:
            self._stop_read_thread()

        self.connected = False
        OrbbecPipeline.get().stop()


class OrbbecColorCamera(OrbbecBaseCamera):
    KIND = "color"

    def __init__(self, config: "OrbbecColorCameraConfig"):
        super().__init__(config)
        # 彩色特有
        self.color_mode = config.color_mode
        self.warmup_s = config.warmup_s
        self._last_missing_color_log_ts: float = 0.0

    def read(self, color_mode: "ColorMode" | None = None) -> Optional[np.ndarray]:
        """
        从 pipeline 的 latest frames 中提取 color view 并做后处理。
        仅读取 pipeline.get_latest_frames()，绝不调用 wait_for_frames()。
        """
        frames = self.pipeline.get_latest_frames()
        if frames is None:
            return None

        color_frame = frames.get_color_frame()
        if color_frame is None:
            now = time.time()
            if now - self._last_missing_color_log_ts > 2.0:
                self._last_missing_color_log_ts = now
                logger.debug(
                    f"{self} missing color_frame (kind={self.KIND}). Pipeline status: {self.pipeline.get_status()}"
                )
            return None

        # 将 SDK 的原始数据变为 numpy array（尽量按期望尺寸解释 buffer）
        target_h = int(getattr(self.config, "height", 0) or 0)
        target_w = int(getattr(self.config, "width", 0) or 0)

        data = color_frame.get_data()
        try:
            buf = np.frombuffer(data, dtype=np.uint8)
            expected = int(self.pipeline.color_height) * int(self.pipeline.color_width) * 3
            if buf.size == expected:
                img = buf.reshape((int(self.pipeline.color_height), int(self.pipeline.color_width), 3))
            else:
                raw = np.asanyarray(data)
                img = raw.reshape((int(self.pipeline.color_height), int(self.pipeline.color_width), 3))
        except Exception as e:
            logger.warning(f"Failed to decode Orbbec color buffer into HxWx3 array: {e}")
            return None

        out = self._postprocess_image(img, color_mode)

        # 系统要求：输出尺寸必须与 json 中配置一致（H/W/3）
        if target_h > 0 and target_w > 0 and (
            out.ndim != 3 or out.shape[0] != target_h or out.shape[1] != target_w
        ):
            out = cv2.resize(out, (target_w, target_h), interpolation=cv2.INTER_LINEAR)

        if out.ndim == 2:
            out = cv2.cvtColor(out, cv2.COLOR_GRAY2BGR)
        elif out.ndim == 3 and out.shape[2] == 1:
            out = cv2.cvtColor(out, cv2.COLOR_GRAY2BGR)

        return out

    def _postprocess_image(self, image: np.ndarray, color_mode: "ColorMode" | None = None) -> np.ndarray:
        # 校验 requested color_mode
        if color_mode and color_mode not in (ColorMode.RGB, ColorMode.BGR):
            raise ValueError(f"Invalid requested color mode '{color_mode}'.")

        out = image
        # 按实例配置转换颜色通道顺序（相机配置 color_mode 表示存储格式）
        if getattr(self, "color_mode", None) == ColorMode.BGR:
            out = cv2.cvtColor(out, cv2.COLOR_RGB2BGR)

        # 旋转处理（若有）
        if self.rotation:
            out = cv2.rotate(out, self.rotation)

        return out


class OrbbecDepthCamera(OrbbecBaseCamera):
    KIND = "depth"

    def __init__(self, config: "OrbbecDepthCameraConfig"):
        super().__init__(config)
        self.warmup_s = config.warmup_s
        self._last_missing_depth_log_ts: float = 0.0
        self.focus_area = getattr(config, "focus_area", None)

    def read(self, color_mode: "ColorMode" | None = None) -> Optional[np.ndarray]:
        """
        从 pipeline 的 latest frames 中提取 depth view（或 depth->color 映射）并做后处理。
        """
        frames = self.pipeline.get_latest_frames()
        if frames is None:
            return None

        depth_frame = frames.get_depth_frame()
        if depth_frame is None:
            now = time.time()
            if now - self._last_missing_depth_log_ts > 2.0:
                self._last_missing_depth_log_ts = now
                logger.debug(
                    f"{self} missing depth_frame (kind={self.KIND}). Pipeline status: {self.pipeline.get_status()}"
                )
            return None

        target_h = int(getattr(self.config, "height", 0) or 0)
        target_w = int(getattr(self.config, "width", 0) or 0)

        # SDK depth 原始数据通常是 Y16；优先按 uint16 解码，确保 reshape 与配置一致
        data = depth_frame.get_data()
        try:
            depth_u16 = np.frombuffer(data, dtype=np.uint16).reshape(
                (int(self.pipeline.depth_height), int(self.pipeline.depth_width))
            )
        except Exception:
            try:
                raw = np.asanyarray(data)
                depth_u16 = raw.reshape((int(self.pipeline.depth_height), int(self.pipeline.depth_width))).astype(
                    np.uint16, copy=False
                )
            except Exception as e:
                logger.warning(f"Failed to decode Orbbec depth buffer into HxW uint16 array: {e}")
                return None

        # 可选：使用 focus_area 固定深度范围（更稳定、更符合 teleop 显示预期）
        if self.focus_area is not None:
            near, far = self.focus_area
            mask_valid = (depth_u16 >= near) & (depth_u16 <= far)
            depth_8u = np.zeros_like(depth_u16, dtype=np.uint8)
            if far > near:
                scale = 255.0 / float(far - near)
                depth_8u[mask_valid] = np.clip((depth_u16[mask_valid] - near) * scale, 0, 255).astype(np.uint8)
        else:
            mask_valid = depth_u16 > 0
            depth_8u = np.zeros_like(depth_u16, dtype=np.uint8)
            if np.any(mask_valid):
                depth_valid = depth_u16[mask_valid]
                min_v = int(depth_valid.min())
                max_v = int(depth_valid.max())
                if max_v > min_v:
                    scale = 255.0 / (max_v - min_v)
                    depth_8u[mask_valid] = np.clip(
                        (depth_u16[mask_valid] - min_v) * scale, 0, 255
                    ).astype(np.uint8)
        img = cv2.applyColorMap(depth_8u, cv2.COLORMAP_JET)
        img[~mask_valid] = 0
        # 旋转（若有）
        if self.rotation:
            img = cv2.rotate(img, self.rotation)

        # 系统要求：输出尺寸必须与 json 中配置一致（H/W/3）
        if target_h > 0 and target_w > 0 and (img.shape[0] != target_h or img.shape[1] != target_w):
            img = cv2.resize(img, (target_w, target_h), interpolation=cv2.INTER_NEAREST)

        return img


class OrbbecDualCamera(Camera):
    """
    单相机版奥比中光相机适配类 
    """

    def __init__(self, config: OrbbecCameraConfig):
        super().__init__(config)
        self.config = config

        self.fps = config.fps
        self.color_mode = config.color_mode
        self.use_depth = config.use_depth
        self.warmup_s = config.warmup_s
        self.focus_area = config.focus_area

        self.color_camera = OrbbecColorCamera(
            OrbbecColorCameraConfig(
                fps=config.fps,
                width=config.width,
                height=config.height,
                color_mode=config.color_mode,
                rotation=config.rotation,
                warmup_s=config.warmup_s,
            )
        )
        self.depth_camera = None
        if self.use_depth:
            self.depth_camera = OrbbecDepthCamera(
                OrbbecDepthCameraConfig(
                    fps=config.fps,
                    width=config.width,
                    height=config.height,
                    rotation=config.rotation,
                    warmup_s=config.warmup_s,
                )
            )

        self.thread: Thread | None = None
        self.stop_event: Event | None = None
        self.frame_lock: Lock = Lock()
        self.latest_frame: np.ndarray | None = None
        self.new_frame_event: Event = Event()

        self.rotation: int | None = get_cv2_rotation(config.rotation)

        if self.height and self.width:
            self.capture_width, self.capture_height = self.width, self.height
            if self.rotation in [cv2.ROTATE_90_CLOCKWISE, cv2.ROTATE_90_COUNTERCLOCKWISE]:
                self.capture_width, self.capture_height = self.height, self.width

    def __str__(self) -> str:
        return f"{self.__class__.__name__}"
    def find_cameras(self):
        return ["default_orbbec_camera"]
    
    @property
    def is_connected(self) -> bool:
        if self.use_depth:
            return (
                self.color_camera is not None
                and self.color_camera.connected
                and self.depth_camera is not None
                and self.depth_camera.connected
            )
        return self.color_camera is not None and self.color_camera.connected

    def connect(self, warmup: bool = True):
        if self.is_connected:
            raise DeviceAlreadyConnectedError(f"{self} is already connected.")

        # 启动共享 pipeline（由 OrbbecPipeline 管理）
        self.color_camera.connect()
        if self.depth_camera is not None:
            self.depth_camera.connect()

        if warmup:
            start_time = time.time()
            while time.time() - start_time < self.warmup_s:
                self.read(timeout_ms=200)
  
        logger.info(f"{self} connected.")
    @staticmethod

    def find_cameras() -> list[dict[str, Any]]:

        found_cameras_info = []
        context = ob.Context()
        device_list = context.query_devices()

        for device in device_list:
            camera_info = {}

            # Get stream profiles for each sensor
            sensors = device.query_sensors()
            for sensor in sensors:
                profiles = sensor.get_stream_profiles()

                for profile in profiles:
                    if profile.is_video_stream_profile() and profile.is_default():
                        vprofile = profile.as_video_stream_profile()
                        stream_info = {
                            "stream_type": vprofile.stream_name(),
                            "format": vprofile.format().name,
                            "width": vprofile.width(),
                            "height": vprofile.height(),
                            "fps": vprofile.fps(),
                        }
                        camera_info["default_stream_profile"] = stream_info

            found_cameras_info.append(camera_info)

        return found_cameras_info
    
    def turn_depth_to_color(self, depth_frame) -> np.ndarray:
        if depth_frame is None:
            logger.warning("No depth frame received")
            return None

        width = depth_frame.get_width()
        height = depth_frame.get_height()
        scale = depth_frame.get_depth_scale()

        depth_data = np.frombuffer(depth_frame.get_data(), dtype=np.uint16)
        depth_data = depth_data.reshape((height, width))

        # 可选滤波 (需提前初始化 self.temporal_filter)
        if hasattr(self, "temporal_filter"):
            depth_data = self.temporal_filter.process(depth_data)

        near, far = self.focus_area  # e.g. (300, 1200)

        depth_data = depth_data.astype(np.uint16)

        # ROI 掩码
        mask_focus = (depth_data >= near) & (depth_data <= far)

        # ---- 1. 创建全黑图 ----
        depth_8u = np.zeros_like(depth_data, dtype=np.uint8)

        # ---- 2. 对 focus_area 范围内做归一化 ----
        if np.any(mask_focus):
            depth_8u[mask_focus] = cv2.normalize(
                depth_data[mask_focus], None, 0, 255,
                cv2.NORM_MINMAX, dtype=cv2.CV_8U
            ).ravel()

        # ---- 3. ROI 范围内做彩色映射，其他保持黑色 ----
        depth_rgb = cv2.applyColorMap(depth_8u, cv2.COLORMAP_JET)
        depth_rgb[~mask_focus] = (0, 0, 0)

        return depth_rgb



    def fuse_color_and_depth(self, color_image: np.ndarray, depth_rgb: np.ndarray) -> np.ndarray:
        if depth_rgb is None:
            return color_image
        if color_image.shape[1] != depth_rgb.shape[1]:
            logger.warning("")
            raise ValueError("Width mismatch between color and depth images.     color width:",color_image.shape[1],"color height",color_image.shape[0],"depth width:",depth_rgb.shape[1])
        stacked = np.vstack((color_image, depth_rgb))
        return stacked

    def read(self, color_mode: ColorMode | None = None, timeout_ms: int = 50000) -> np.ndarray:
        if not self.is_connected:
            raise DeviceNotConnectedError(f"{self} is not connected.")

        frames = self._get_latest_frames(timeout_ms=timeout_ms)
        if frames is None:
            return None

        color_image = self._extract_color_from_frames(frames, color_mode)
        if color_image is None:
            return None

        if self.use_depth:
            depth_frame = frames.get_depth_frame() if frames is not None else None
            depth_rgb = self.turn_depth_to_color(depth_frame)
            if depth_rgb is not None and self.rotation:
                depth_rgb = cv2.rotate(depth_rgb, self.rotation)
            fused = self.fuse_color_and_depth(color_image, depth_rgb)
            return fused
        else:
            return color_image

    def _get_latest_frames(self, timeout_ms: int):
        pipeline = self.color_camera.pipeline
        deadline = time.time() + (timeout_ms / 1000.0)
        frames = pipeline.get_latest_frames()
        while frames is None and time.time() < deadline:
            frames = pipeline.get_latest_frames()
        return frames

    def _extract_color_from_frames(self, frames, color_mode: ColorMode | None):
        color_frame = frames.get_color_frame()
        if color_frame is None:
            return None
        raw = np.asanyarray(color_frame.get_data())
        try:
            img = raw.reshape(
                (self.color_camera.pipeline.color_height, self.color_camera.pipeline.color_width, 3)
            )
        except Exception:
            img = raw
        return self.color_camera._postprocess_image(img, color_mode)

    def _read_loop(self):
     
        repeat_count = 0

        while not self.stop_event.is_set():
            
            try:
                color_image = self.read(timeout_ms=5000)
                if color_image is None :
                    continue
                with self.frame_lock:
                    self.latest_frame = color_image
                self.new_frame_event.set()
            except DeviceNotConnectedError:
                break
            except Exception as e:
                logger.warning(f"Error reading frame in background thread for {self}: {e}")

    def _start_read_thread(self) -> None:
        if self.thread is not None and self.thread.is_alive():
            self.thread.join(timeout=0.1)
        if self.stop_event is not None:
            self.stop_event.set()

        self.stop_event = Event()
        self.thread = Thread(target=self._read_loop, name=f"{self}_read_loop")
        self.thread.daemon = True
        self.thread.start()

    def _stop_read_thread(self):
        if self.stop_event is not None:
            self.stop_event.set()
        if self.thread is not None and self.thread.is_alive():
            self.thread.join(timeout=2.0)
        self.thread = None
        self.stop_event = None

    def async_read(self, timeout_ms: float = 5000) -> np.ndarray:
        if not self.is_connected:
            raise DeviceNotConnectedError(f"{self} is not connected.")

        if self.thread is None or not self.thread.is_alive():
            self._start_read_thread()

        if not self.new_frame_event.wait(timeout=timeout_ms / 1000.0):
            raise TimeoutError(f"Timed out waiting for frame from camera {self}.")

        with self.frame_lock:
            frame = self.latest_frame
            self.new_frame_event.clear()

        if frame is None:
            raise RuntimeError(f"Event set but no frame available for {self}.")

        return frame

    def disconnect(self):
        if not self.is_connected and self.thread is None:
            raise DeviceNotConnectedError(f"{self} already disconnected.")

        if self.thread is not None:
            self._stop_read_thread()

        if self.color_camera is not None and self.color_camera.connected:
            self.color_camera.connected = False
        if self.depth_camera is not None and self.depth_camera.connected:
            self.depth_camera.connected = False
        OrbbecPipeline.get().stop()

        logger.info(f"{self} disconnected.")
