from dataclasses import dataclass
from ..configs import CameraConfig, ColorMode, Cv2Rotation
from typing import Tuple, Optional


@CameraConfig.register_subclass("orbbec_color")
@dataclass
class OrbbecColorCameraConfig(CameraConfig):

    choice_name = "orbbec_color"

    fps: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None

    color_mode: ColorMode = ColorMode.RGB
    rotation: Cv2Rotation = Cv2Rotation.NO_ROTATION
    warmup_s: int = 1

    def __post_init__(self):
        # 1. color_mode 校验（仅彩色相机有）
        if self.color_mode not in (ColorMode.RGB, ColorMode.BGR):
            raise ValueError(
                f"`color_mode` is expected to be {ColorMode.RGB.value} or {ColorMode.BGR.value}, "
                f"but {self.color_mode} is provided."
            )

        # 2. rotation 校验
        if self.rotation not in (
            Cv2Rotation.NO_ROTATION,
            Cv2Rotation.ROTATE_90,
            Cv2Rotation.ROTATE_180,
            Cv2Rotation.ROTATE_270,
        ):
            raise ValueError(
                f"`rotation` is expected to be in "
                f"{(Cv2Rotation.NO_ROTATION, Cv2Rotation.ROTATE_90, Cv2Rotation.ROTATE_180, Cv2Rotation.ROTATE_270)}, "
                f"but {self.rotation} is provided."
            )

        # 3. fps / width / height 一致性校验
        values = (self.fps, self.width, self.height)
        if any(v is not None for v in values) and any(v is None for v in values):
            raise ValueError(
                "For `fps`, `width` and `height`, either all of them need to be set, or none of them."
            )
    @property
    def type(self) -> str:
        return str(self.get_choice_name(self.__class__))


@CameraConfig.register_subclass("orbbec_depth")
@dataclass
class OrbbecDepthCameraConfig(CameraConfig):

    choice_name = "orbbec_depth"

    fps: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None

    rotation: Cv2Rotation = Cv2Rotation.NO_ROTATION
    warmup_s: int = 1
    focus_area: Tuple[int, int] | None = None

    def __post_init__(self):
        # 1. rotation 校验（深度也需要）
        if self.rotation not in (
            Cv2Rotation.NO_ROTATION,
            Cv2Rotation.ROTATE_90,
            Cv2Rotation.ROTATE_180,
            Cv2Rotation.ROTATE_270,
        ):
            raise ValueError(
                f"`rotation` is expected to be in "
                f"{(Cv2Rotation.NO_ROTATION, Cv2Rotation.ROTATE_90, Cv2Rotation.ROTATE_180, Cv2Rotation.ROTATE_270)}, "
                f"but {self.rotation} is provided."
            )

        # 2. fps / width / height 一致性校验
        values = (self.fps, self.width, self.height)
        if any(v is not None for v in values) and any(v is None for v in values):
            raise ValueError(
                "For `fps`, `width` and `height`, either all of them need to be set, or none of them."
            )

        if self.focus_area is not None:
            near, far = self.focus_area
            if not isinstance(near, int) or not isinstance(far, int) or near < 0 or far <= near:
                raise ValueError("`focus_area` is expected to be a tuple/list like [near, far] with 0 <= near < far.")
    @property
    def type(self) -> str:
        return str(self.get_choice_name(self.__class__))


@CameraConfig.register_subclass("orbbec_legacy")
@CameraConfig.register_subclass("orbbec")
@dataclass
class OrbbecCameraConfig(CameraConfig):
    choice_name = "Orbbec"

    fps: Optional[int] = None
    width: Optional[int] = None
    height: Optional[int] = None

    color_mode: ColorMode = ColorMode.RGB
    use_depth: bool = False
    rotation: Cv2Rotation = Cv2Rotation.NO_ROTATION
    warmup_s: int = 1
    focus_area: Tuple[int, int] = (200, 1200)

    def __post_init__(self):
        if self.color_mode not in (ColorMode.RGB, ColorMode.BGR):
            raise ValueError(
                f"`color_mode` is expected to be {ColorMode.RGB.value} or {ColorMode.BGR.value}, "
                f"but {self.color_mode} is provided."
            )

        if self.rotation not in (
            Cv2Rotation.NO_ROTATION,
            Cv2Rotation.ROTATE_90,
            Cv2Rotation.ROTATE_180,
            Cv2Rotation.ROTATE_270,
        ):
            raise ValueError(
                f"`rotation` is expected to be in "
                f"{(Cv2Rotation.NO_ROTATION, Cv2Rotation.ROTATE_90, Cv2Rotation.ROTATE_180, Cv2Rotation.ROTATE_270)}, "
                f"but {self.rotation} is provided."
            )

        values = (self.fps, self.width, self.height)
        if any(v is not None for v in values) and any(v is None for v in values):
            raise ValueError(
                "For `fps`, `width` and `height`, either all of them need to be set, or none of them."
            )
