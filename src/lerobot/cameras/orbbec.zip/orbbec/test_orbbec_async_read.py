#!/usr/bin/env python3

from __future__ import annotations

import logging
import os
import time

import cv2
import numpy as np

from ..configs import ColorMode, Cv2Rotation
from .camera_orbbec import OrbbecColorCamera, OrbbecDepthCamera
from .configuration_orbbec import OrbbecColorCameraConfig, OrbbecDepthCameraConfig


_warned_no_gui = False


def image_show(window_name: str, image) -> bool:
    try:
        cv2.imshow(window_name, image)
        return True
    except cv2.error:
        # GUI not supported, skip display
        global _warned_no_gui
        if not _warned_no_gui:
            _warned_no_gui = True
            print(
                "cv2.imshow() failed (likely running headless / no GUI). "
                "Depth/Color windows will not appear. "
                "Try running on a desktop session, or set DISPLAY / X11 forwarding."
            )
        return False


def main() -> None:
    level_name = os.environ.get("LOGLEVEL", "INFO").upper()
    logging.basicConfig(
        level=getattr(logging, level_name, logging.INFO),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    color_cfg = OrbbecColorCameraConfig(
        fps=30,
        width=640,
        height=480,
        color_mode=ColorMode.RGB,
        rotation=Cv2Rotation.NO_ROTATION,
        warmup_s=1,
    )

    depth_cfg = OrbbecDepthCameraConfig(
        fps=30,
        width=640,
        height=400,
        rotation=Cv2Rotation.NO_ROTATION,
        warmup_s=1,
    )

    color_camera = OrbbecColorCamera(color_cfg)
    depth_camera = OrbbecDepthCamera(depth_cfg)

    try:
        color_camera.connect()
        depth_camera.connect()
    except Exception as e:
        print(f"Failed to connect Orbbec cameras: {e}")
        return

    color_window = "Orbbec Color (press q to quit)"
    depth_window = "Orbbec Depth (press q to quit)"
    last_diag_ts = 0.0
    try:
        while True:
            color_frame = None
            depth_frame = None

            try:
                color_frame = color_camera.async_read(timeout_ms=2000)
            except TimeoutError:
                # Keep going: color can take time to warm up / pipeline may restart.
                pass

            try:
                depth_frame = depth_camera.async_read(timeout_ms=2000)
            except TimeoutError:
                # Keep going: depth can take longer to appear or might not be enabled.
                pass

            now = time.time()
            if now - last_diag_ts > 2.0:
                last_diag_ts = now
                try:
                    frames = depth_camera.pipeline.get_latest_frames()
                    depth_present = bool(frames is not None and frames.get_depth_frame() is not None)
                    color_present = bool(frames is not None and frames.get_color_frame() is not None)
                except Exception:
                    depth_present = False
                    color_present = False
                print(
                    "Pipeline status:",
                    depth_camera.pipeline.get_status(),
                    f"frames_color={color_present} frames_depth={depth_present}",
                )

            if color_frame is not None:
                image_show(color_window, color_frame)

            if depth_frame is not None:
                # Most of the time OrbbecDepthCamera.read() already returns a colorized uint8 image.
                if isinstance(depth_frame, np.ndarray) and depth_frame.ndim == 2:
                    depth_vis = cv2.normalize(depth_frame, None, 0, 255, cv2.NORM_MINMAX)
                    depth_vis = depth_vis.astype("uint8")
                    depth_vis = cv2.applyColorMap(depth_vis, cv2.COLORMAP_JET)
                else:
                    depth_vis = depth_frame
                image_show(depth_window, depth_vis)

            if cv2.waitKey(1) & 0xFF == ord("q"):
                break
    finally:
        if depth_camera.is_connected:
            depth_camera.disconnect()
        if color_camera.is_connected:
            color_camera.disconnect()
        try:
            cv2.destroyAllWindows()
        except cv2.error:
            # GUI not supported, skip
            pass


if __name__ == "__main__":
    main()
